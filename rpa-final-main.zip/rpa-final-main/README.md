# Iniciar Projeto

-----
## 1 - Criar Ambiente Venv

```bash
python -m venv venv
```

```bash
.\venv\Scripts\activate
```

## 2 - Instalar Libs

```bash
pip install -r required.txt
```
