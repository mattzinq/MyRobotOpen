from navigation import Browser, PageObjects
from desktop_navigation import Fakturama
from gerencia_arquivos import Arquivos
from compra_produtos import CompraProdutos
import time
import random

class ColetaDados:
    def __init__(self):
        pass

    def consulta_produtos():
        site = 'https://www.saucedemo.com/'
        login = 'problem_user'
        senha = 'secret_sauce'

        print('Carregando Browser...')
        driver = Browser.chrome_browser(site)
        print('Browser carregado...')
        print('Efetuando Login...')
        PageObjects.login(driver, login, senha)
        print('Login Efetuado...')
        time.sleep(1)
        print('Começando web scraping')
        data_collect = PageObjects.coleta_dados(driver)
        print('Dados Coletados...')
        print('Salvando dados...')
        header = ['Titulo', 'Descricao', 'Valor']
        Arquivos.cria_csv(header, data_collect, './assets/data.csv')
        print('Dados Salvos...')

    def consulta_clientes():
        site = "https://www.fakenamegenerator.com/gen-random-br-br.php"
        print('Carregando Browser...')
        driver = Browser.chrome_browser(site)
        print('Browser carregado...')
        print('Começando web scraping')
        data_collect = PageObjects.executa_fake_data(driver,3)
        driver.close()
        print('Dados Coletados...')
        print('Salvando dados...')
        header = ['Nome', 'Sobrenome', 'CEP']
        Arquivos.cria_csv(header, data_collect, './assets/data_clientes.csv')
        print('Dados Salvos...')

        return data_collect[0]



class Compra:
    def __init__(self):
        pass    
    
    def compra_produtos_sauce_demo(cliente):
        site = 'https://www.saucedemo.com/'
        login = 'standard_user'
        senha = 'secret_sauce'

        # Alterar os dados abaixo com os gerados no site
        # Usando o DF
        f_name = cliente[0]
        l_name = cliente[1]
        cep = cliente[2]

        print('Carregando Browser...⏳')
        driver = Browser.chrome_browser(site)
        driver.implicitly_wait(20)
        print('Browser carregado!✅')
        print('Efetuando Login...⏳')
        PageObjects.login(driver, login, senha)
        print('Login Efetuado!✅')
        time.sleep(1)
        CompraProdutos.seleciona_produtos(driver, f_name, l_name, cep)

    def compra_produtos_fakturama(cliente):
        produtos = ['add-to-cart-sauce-labs-backpack',
                   'add-to-cart-sauce-labs-bike-light',
                   'add-to-cart-sauce-labs-onesie']
        Fakturama.novo_pedido(produtos, cliente)

class CadastraDados:
    def __init__(self):
        pass
    def cadastra_produtos():
        print('Inicializando sistema....')
        Fakturama.inicia_sistema(r'.\assets\seletores\aguarda_botoes.png', 100, 2)
        print('Sistema Inicializado... ')

        print('Lendo Produtos... ')
        produtos = Arquivos.ler_csv('./assets/data.csv')
        print('Produtos Lidos... ')

        print('Iniciando cadastramento... ')
        count = 0
        for produto in produtos:
            if count == 0:
                #Pula Header
                count += 1
                continue
            print(f'Cadastrando item {count}... ')
            Fakturama.cadastra_item(count, produto[0], produto[1], produto[2])
            print(f'Item {count}... Cadastrado')
            count += 1

    def cadastra_clientes():
        print('Localizando sistema....')
        result_fak = Fakturama.foca_janela('Fakturama - C:\Temp\Fakturama')

        if result_fak is None:
            print('Inicializando sistema....')
            Fakturama.inicia_sistema(r'.\assets\seletores\aguarda_botoes.png', 100, 2)
            print('Sistema Inicializado... ')

        Fakturama.foca_janela('Fakturama - C:\Temp\Fakturama')

        print('Lendo Clientes... ')
        clientes = Arquivos.ler_csv('./assets/data_clientes.csv')
        print('Clientes Lidos... ')

        print('Iniciando cadastramento... ')
        count = 0
        for cliente in clientes:
            if count == 0:
                # Pula Header
                count += 1
                continue
            print(f'Cadastrando item {count}... ')
            pg = Fakturama.cadastra_contato(cliente[0], cliente[1], cliente[2])
            print(f'Item {count}... Cadastrado')
            count += 1

        time.sleep(5)


