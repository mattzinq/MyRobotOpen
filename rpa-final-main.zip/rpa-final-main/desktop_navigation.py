import pyautogui as pg
import os
import time
import sys
from datetime import datetime
# from prefect import flow, task
import win32gui
import win32com.client
import random

class DesktopTools:
    def try_locate_image(imagePath, try_count=0, tries=20):
        while try_count >= 0:
            time.sleep(20)
            position = pg.locateOnScreen(imagePath, grayscale=True, confidence=0.7)
            try_count += 1
            print(try_count)
            if try_count >= tries or position is not None:
                break
        try:
            if position is not None:
                print(f"position = {position}")
                return position
            else:
                raise Exception(f'Imagem: "{imagePath}", não localizada')
        except Exception as error:
            print(error)
            pg.screenshot(str("./assets/images/Error_screenshot.png"))
            sys.exit()
class Fakturama:
    # @task
    def inicia_sistema(imagem, tentativas=5, tempo=1, path_sistema = r'C:\Program Files\Fakturama2\Fakturama.exe'):
        # Inicia Sistema
        os.startfile(path_sistema)
        count = 0
        posicao = None

        while count >= 0:
            posicao = pg.locateOnScreen(imagem, grayscale=True, confidence=0.7)
            count += 1
            print(f'Aguardando carregamento. Tentativa {count}')
            time.sleep(tempo)
            if count >= tentativas or posicao is not None:
                break

        try:
            if posicao is not None:
                print(f"posição em {posicao}")
                return posicao
            else:
                raise Exception(f'Imagem: "{imagem}", não localizada')
        except Exception as error:
            print(error)
            timestamp = datetime.now().strftime('%d_%m_%Y_%H_%I_%S')
            pg.screenshot(rf'.\assets\logs\erros\FAK_ERRO_INICIA_SISTEMA_{timestamp}.png')
            sys.exit()

        print('Progama aberto...')

    # @task
    def foca_janela(nome):
        def cb(x, y):
            return y.append(x)

        wins = []
        win32gui.EnumWindows(cb, wins)
        nameRe = nome

        # now check to see if any match our regexp:
        tgtWin = -1
        for win in wins:
            txt = win32gui.GetWindowText(win)
            if nameRe == txt:
                # if nameRe.match(txt):
                tgtWin = win
                break

        if tgtWin >= 0:
            shell = win32com.client.Dispatch('WScript.Shell')
            shell.SendKeys('%')
            win32gui.SetForegroundWindow(tgtWin)

    # @task
    def cadastra_item(id, nome, descricao, valor):
        Fakturama.foca_janela('Fakturama - C:\Temp\Fakturama')

        botao = pg.locateOnScreen(r'.\assets\seletores\novo_produto.png', grayscale=True, confidence=0.7)
        pg.leftClick(botao, interval=2)

        label = pg.locateOnScreen(r'.\assets\seletores\label_novo_produto.png', grayscale=True, confidence=0.7)
        pg.leftClick(label, interval=2)

        pg.press('tab', 2, 0.5)
        pg.typewrite(str(id))

        pg.press('tab', 1, 0.5)
        pg.typewrite(str(nome))

        pg.press('tab', 4, 0.5)
        pg.typewrite(str(descricao))

        pg.press('tab', 1, 0.5)
        pg.typewrite(str(valor))

        # Salva Produto
        pg.hotkey('ctrl', 's')

        # Fecha Aba
        pg.hotkey('ctrl', 'w')

    def cadastra_contato(nome, sobrenome, cep):
        new_contact = DesktopTools.try_locate_image("./assets/seletores/novo_cliente.png", tries=20)

        if new_contact is not None:
            pg.click(new_contact, interval=2)
            pg.press('tab', 4, interval=0.5)
            pg.typewrite(nome)
            print(nome)
            pg.press('tab')
            pg.typewrite(sobrenome)
            print(sobrenome)
            pg.press('tab', 8, interval=0.5)
            pg.typewrite(cep)
            print(cep)
            pg.hotkey("ctrl", "s")
            pg.hotkey('ctrl', 'w')

    def novo_pedido(produtos:list, cliente):
        Fakturama.foca_janela('Fakturama - C:\Temp\Fakturama')

        botao_new_order = pg.locateOnScreen(r'.\assets\seletores\nova_ordem.png', grayscale=True, confidence=0.7)
        pg.leftClick(botao_new_order, interval=2)
        time.sleep(1)

        botao_add_cliente = pg.locateOnScreen(r'.\assets\seletores\adiciona_cliente.png', grayscale=True,
                                              confidence=0.7)
        pg.leftClick(botao_add_cliente, interval=2)
        time.sleep(1)

        pg.write(f'{cliente[0]} {cliente[1]} ')
        botao_seleciona_cli = pg.locateOnScreen(r'.\assets\seletores\seleciona_primeiro_lista.png', grayscale=True,
                                                confidence=0.7)
        pg.leftClick(botao_seleciona_cli, interval=2)
        time.sleep(1)

        botao_seleciona_ok1 = pg.locateOnScreen(r'.\assets\seletores\ok.png', grayscale=True, confidence=0.7)
        pg.leftClick(botao_seleciona_ok1, interval=2)
        time.sleep(1)


        for item in produtos:
            print('Clicando no item...')
            botao_add_produto = pg.locateOnScreen(r'.\assets\seletores\adiciona_item.png', grayscale=True, confidence=0.7)
            botao_add_produto = (
                botao_add_produto.left + 1, botao_add_produto.top + 4, botao_add_produto.width,
                botao_add_produto.height)
            pg.leftClick(botao_add_produto, interval=2)
            time.sleep(2)

            pg.write(str(item).replace("add-to-cart-", "").replace("-", " "))
            print('Item selecionado!')
        time.sleep(1)

        pg.hotkey('ctrl', 's')

        time.sleep(3)

        botao_seleciona_ok1 = pg.locateOnScreen(r'.\assets\seletores\print.png', grayscale=True, confidence=0.7)
        pg.leftClick(botao_seleciona_ok1, interval=2)
        time.sleep(1)





