import csv

class Arquivos:
    def cria_csv(header:list, data:list, path_arquivo:str):
        file = open(path_arquivo, 'w', encoding='UTF8', newline='')

        writer = csv.writer(file)

        writer.writerow(header)

        writer.writerows(data)


        file.close()

    def ler_csv(path_arquivo:str):
        with open(path_arquivo) as csvfile:
            spamreader = csv.reader(csvfile)
            data = []
            for row in spamreader:
                data.append(row)

            csvfile.close()
        return data

