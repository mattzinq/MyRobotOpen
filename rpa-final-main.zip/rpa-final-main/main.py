from rpa import ColetaDados, CadastraDados, Compra
#Instância das Classes
coleta = ColetaDados
compra = Compra
cadastro = CadastraDados

#Executa Métodos
coleta.consulta_produtos()
cadastro.cadastra_produtos()

cliente = coleta.consulta_clientes()
cadastro.cadastra_clientes()

compra.compra_produtos_sauce_demo(cliente)
compra.compra_produtos_fakturama(cliente)



