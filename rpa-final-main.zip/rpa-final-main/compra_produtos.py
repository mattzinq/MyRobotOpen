import time
import pyautogui
from navigation import Browser, PageObjects, Waits
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC



class CompraProdutos:

    def seleciona_produtos(driver, first_name, last_name, cep):

        # Inicia a seleção dos produtos   
        print('Selecionando produtos para Compra...⏳')
        list_id = ['add-to-cart-sauce-labs-backpack', 
                   'add-to-cart-sauce-labs-bike-light', 
                   'add-to-cart-sauce-labs-onesie']
        
        for item in list_id:
            print('Clicando no item...')
            #driver.find_element(By.XPATH, f'//button[@id="{item}"]').click()
            Waits.clickable(driver, By.XPATH, f'//button[@id="{item}"]').click()
            print('Item selecionado!')
        time.sleep(1)

        # A partir daqui, começa a etapa de compra dos produtos
        print('Clicando no carrinho...')
        driver.find_element(By.XPATH, '//div[@id="shopping_cart_container"]').click()
        time.sleep(1)

        print('Indo até a aba de Checkout') # Clica no botão de Checkout
        Waits.clickable(driver, By.XPATH, '//button[@class="btn btn_action btn_medium checkout_button "]').click()
        time.sleep(1)
        print('Inserindo credenciais...')

        # Aqui insere as credenciais no sistema
        Waits.visible(driver, By.XPATH, '//input[@id="first-name"]').send_keys(first_name)
        Waits.visible(driver, By.XPATH, '//input[@id="last-name"]').send_keys(last_name)
        Waits.visible(driver, By.XPATH, '//input[@id="postal-code"]').send_keys(cep)

        print('Credenciais inseridas, passando para tela de checkout final...')
        Waits.clickable(driver, By.XPATH, '//input[@id="continue"]').click()
        
        # Aguarda o "Preço Total" aparecer na página
        Waits.visible(driver, By.XPATH, '//div[text()="Price Total"]')

        print('Tela do Checkout final!')
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);") # Scrolla a tela para baixo
        driver.execute_script("document.body.style.zoom='65%'") # Reduz o Zoom para printar a Tela
        time.sleep(1)

        print('Printando a tela...⏳')
        pyautogui.screenshot('./assets/screenshots/checkout_final.png') # func para tirar print
        print('Tela printada com sucesso!✅')
        time.sleep(1)

        # Recupera o zoom em 100% e clica em finalizar
        driver.execute_script("document.body.style.zoom='100%'")
        Waits.clickable(driver, By.XPATH, '//button[@id="finish"]').click()

        # Espera aparecer a mensagem
        Waits.visible(driver, By.XPATH, '//h2[text()="Thank you for your order!"]')
        driver.execute_script("document.body.style.zoom='100%'")
        time.sleep(1)
        
        # Printa a tela
        print('Printando a tela...⏳')
        pyautogui.screenshot('./assets/screenshots/tela_final_saucedemo.png')
        print('Tela printada com sucesso!✅')

        Waits.clickable(driver, By.XPATH, '//button[@id="back-to-products"]').click()
        print('Compras concluídas!💬')
        time.sleep(2)
        

##TESTES:
if __name__ == "__main__":
    site = 'https://www.saucedemo.com/'
    login = 'standard_user'
    senha = 'secret_sauce'

    print('Carregando Browser...⏳')
    driver = Browser.chrome_browser(site)
    driver.implicitly_wait(40)
    print('Browser carregado!✅')
    print('Efetuando Login...⏳')
    PageObjects.login(driver, login, senha)
    print('Login Efetuado!✅')
    time.sleep(1)
    CompraProdutos.seleciona_produtos(driver, 'José', 'Teste', '99400000')