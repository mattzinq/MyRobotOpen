from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


# Classe para navegação no browser
class Browser:
    def chrome_browser(site:str):
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument('--start-maximized')
        chrome_options.add_argument('--enable-chrome-browser-cloud-management')
        chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
        chrome_options.binary_location = "./chrome/chrome-win64/chrome.exe"
        chrome_driver_path = "./chrome/chromedriver-win64/chromedriver.exe"
        service_options = webdriver.ChromeService(executable_path=chrome_driver_path)
        driver = webdriver.Chrome(options=chrome_options, service=service_options)

        driver.get(site)

        return (driver)


class PageObjects:
    def login(driver, login, senha):
        input_login = Waits.visible(driver, By.XPATH, '//input[@id="user-name"]')
        input_login.send_keys(login)
        input_senha = Waits.visible(driver, By.XPATH, '//input[@id="password"]')
        input_senha.send_keys(senha)
        button = Waits.clickable(driver, By.XPATH, '//input[@id="login-button"]')
        button.click()

    def coleta_dados(driver):
        item_1_titulo = Waits.visible(driver, By.XPATH, '//*[@id="item_4_title_link"]/div').text
        item_1_descricao = Waits.visible(driver, By.XPATH,
                                         '//*[@id="inventory_container"]/div/div[1]/div[2]/div[1]/div').text
        item_1_valor = Waits.visible(driver, By.XPATH,
                                     '//*[@id="inventory_container"]/div/div[1]/div[2]/div[2]/div').text
        item_2_titulo = Waits.visible(driver, By.XPATH, '//*[@id="item_0_title_link"]/div').text
        item_2_descricao = Waits.visible(driver, By.XPATH,
                                         '//*[@id="inventory_container"]/div/div[2]/div[2]/div[1]/div').text
        item_2_valor = Waits.visible(driver, By.XPATH,
                                     '//*[@id="inventory_container"]/div/div[2]/div[2]/div[2]/div').text
        item_3_titulo = Waits.visible(driver, By.XPATH, '//*[@id="item_1_title_link"]/div').text
        item_3_descricao = Waits.visible(driver, By.XPATH,
                                         '//*[@id="inventory_container"]/div/div[3]/div[2]/div[1]/div').text
        item_3_valor = Waits.visible(driver, By.XPATH,
                                     '//*[@id="inventory_container"]/div/div[3]/div[2]/div[2]/div').text
        item_4_titulo = Waits.visible(driver, By.XPATH, '//*[@id="item_5_title_link"]/div').text
        item_4_descricao = Waits.visible(driver, By.XPATH,
                                         '//*[@id="inventory_container"]/div/div[4]/div[2]/div[1]/div').text
        item_4_valor = Waits.visible(driver, By.XPATH,
                                     '//*[@id="inventory_container"]/div/div[4]/div[2]/div[2]/div').text
        item_5_titulo = Waits.visible(driver, By.XPATH, '//*[@id="item_2_title_link"]/div').text
        item_5_descricao = Waits.visible(driver, By.XPATH,
                                         '//*[@id="inventory_container"]/div/div[5]/div[2]/div[1]/div').text
        item_5_valor = Waits.visible(driver, By.XPATH,
                                     '//*[@id="inventory_container"]/div/div[5]/div[2]/div[2]/div').text
        item_6_titulo = Waits.visible(driver, By.XPATH, '//*[@id="item_3_title_link"]/div').text
        item_6_descricao = Waits.visible(driver, By.XPATH,
                                         '//*[@id="inventory_container"]/div/div[6]/div[2]/div[1]/div').text
        item_6_valor = Waits.visible(driver, By.XPATH,
                                     '//*[@id="inventory_container"]/div/div[6]/div[2]/div[2]/div').text
        return [
            [item_1_titulo, item_1_descricao, item_1_valor],
            [item_2_titulo, item_2_descricao,item_2_valor],
            [item_3_titulo, item_3_descricao, item_3_valor],
            [item_4_titulo, item_4_descricao, item_4_valor],
            [item_5_titulo, item_5_descricao, item_5_valor],
            [item_6_titulo, item_6_descricao, item_6_valor]
        ]

    def executa_fake_data(driver, quantidade:int):
        dados = []
        for i in range(quantidade):
            nome = driver.find_element(By.XPATH, '//div[@class="address"]/h3[1]').text.split()[0]

            sobrenome = driver.find_element(By.XPATH, '//div[@class="address"]/h3[1]').text.split()[-1]

            cep = driver.find_element(By.XPATH, '//div[@class="adr"]').text.splitlines()[2]

            driver.refresh()

            dados.append([nome, sobrenome, cep])

        return dados


# Classe que aguarda seletores estarem disponíveis
class Waits:
    def clickable(driver, by_type, selector):
        return WebDriverWait(driver, 10).until(EC.element_to_be_clickable((by_type, selector)))

    def visible(driver, by_type, selector):
        return WebDriverWait(driver, 10).until(EC.visibility_of_element_located((by_type, selector)))